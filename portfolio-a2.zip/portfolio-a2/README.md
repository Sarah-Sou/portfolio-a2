# ExpressJS Portfolio Website

**Course:** INFR3120  
**Assignment:** 2 – ExpressJS Portfolio  
**Name:** Sarah Soueidan  
**Date:** November 2025  

---

## Overview
This project is my personal portfolio website made with **ExpressJS** and **EJS**.  
It includes four main pages — Home, About Me, Projects, and Contact Me.  
Each page uses the same header, navbar, and footer so the whole site looks consistent.  
The purpose of this project is to show that I can build and organize a small website using Node.js, Express, and EJS templates.

---

## Technologies Used
- Node.js and ExpressJS  
- EJS (Embedded JavaScript templates)  
- Bootstrap 5 for layout and design  
- Font Awesome for icons  
- JavaScript  

---

## Features
- Dynamic routing with ExpressJS  
- Shared EJS partials for header, navigation, and footer  
- Responsive layout using Bootstrap  
- GitHub and LinkedIn links in the footer  
- Simple contact form on the Contact page  

---

## How to Run the Project
1. Open a terminal in the project folder.  
2. Install the required dependencies:
   ```bash
   npm install
3. Start the server:
   ```bash
   npm start

## Links
- GitHub: [https://github.com/Sarah-Sou](https://github.com/Sarah-Sou)
- LinkedIn: [https://www.linkedin.com/in/sarah-soueidan-67b63a35a](https://www.linkedin.com/in/sarah-soueidan-67b63a35a)
